package com.example.mangareader;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;
import com.example.mangareader.Common.Common;
import com.example.mangareader.Adapter.MyViewPagerAdapter;
import com.example.mangareader.Model.Chapter;
import com.wajahatkarim3.easyflipviewpager.BookFlipPageTransformer;

public class ViewComicActivity extends AppCompatActivity {

    ViewPager viewPager;
    TextView txt_chapter_name;
    View back,next;
    private Object Common;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_comic);

        viewPager =(ViewPager)findViewById(R.id.view_pager);
        txt_chapter_name = (TextView)findViewById(R.id.txt_chapter_name);
        back =findViewById(R.id.chapter_back);
        next = findViewById(R.id.chapter_next);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(com.example.mangareader.Common.Common.chapterIndex == 0)
                    Toast.makeText(ViewComicActivity.this, "You are reading the first chapter", Toast.LENGTH_SHORT).show();
                else{
                    com.example.mangareader.Common.Common.chapterIndex--;
                    fetchLinks(com.example.mangareader.Common.Common.chapterList.get(com.example.mangareader.Common.Common.chapterIndex));
                }
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    if(com.example.mangareader.Common.Common.chapterIndex == com.example.mangareader.Common.Common.chapterList.size()-1)
                        Toast.makeText(ViewComicActivity.this, "You are reading the last chapter", Toast.LENGTH_SHORT).show();
                    else{
                        com.example.mangareader.Common.Common.chapterIndex++;
                        fetchLinks(com.example.mangareader.Common.Common.chapterList.get(com.example.mangareader.Common.Common.chapterIndex));
                }
            }
        });
        fetchLinks(com.example.mangareader.Common.Common.chapterSelected);
    }
    private void fetchLinks(Chapter chapter)
    {
        if (chapter.Links!=null)
        {
            if (chapter.Links.size()>0) {
                MyViewPagerAdapter adapter = new MyViewPagerAdapter(getBaseContext(),chapter.Links);
                viewPager.setAdapter(adapter);

                txt_chapter_name.setText(com.example.mangareader.Common.Common.formatString(com.example.mangareader.Common.Common.chapterSelected.Name));
//                Common.chapterSelected.Name
                BookFlipPageTransformer bookFlipPageTransformer = new BookFlipPageTransformer();
                bookFlipPageTransformer.setScaleAmountPercent(10f);
                viewPager.setPageTransformer(true, bookFlipPageTransformer);
            }
        }
        else
        {
            Toast.makeText(this, "No image here", Toast.LENGTH_SHORT).show();
        }
    }
}