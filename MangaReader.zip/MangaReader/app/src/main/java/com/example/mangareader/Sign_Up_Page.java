package com.example.mangareader;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Sign_Up_Page extends AppCompatActivity {

    private FirebaseAuth mAuth;
    //DatabaseReference dbReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://comic-reader-75cf9-default-rtdb.firebaseio.com/");
    //SIGNUP PAGE
    TextInputEditText reg_user, reg_pass, conf_pass;
    TextView login_txt;
    Button signup_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sigup_page);

        reg_user = findViewById(R.id.reg_user);
        reg_pass = findViewById(R.id.reg_pass);
        conf_pass = findViewById(R.id.confirm_pass);
        login_txt = findViewById(R.id.login_text);
        signup_btn = findViewById(R.id.signup_btn);
        mAuth = FirebaseAuth.getInstance();


        signup_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Gets data from edit_texts
                final String username = reg_user.getText().toString();
                final String password = reg_pass.getText().toString();
                final String confirm_pass = conf_pass.getText().toString();

                //Check whether the data is fully filled
                if(TextUtils.isEmpty(username) ||  TextUtils.isEmpty(password) ||  TextUtils.isEmpty(confirm_pass))
                {
                    Toast.makeText(Sign_Up_Page.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                    return;
                }
                else if(!password.equals(confirm_pass)) //check if password and confirm passwords match with each other
                {
                    Toast.makeText(Sign_Up_Page.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                    return;
                }

                mAuth.createUserWithEmailAndPassword(username, password)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                    Toast.makeText(Sign_Up_Page.this, "Success !", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(Sign_Up_Page.this, Login_Page.class));
                                } else {
                                    // If sign in fails, display a message to the user.
                                    Toast.makeText(Sign_Up_Page.this, "Authentication failed.",
                                            Toast.LENGTH_SHORT).show();

                                }
                            }
                        });
            }
        });
        login_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }



}