package com.example.mangareader.Common;

import com.example.mangareader.Model.Chapter;
import com.example.mangareader.Model.Comic;

import java.util.ArrayList;
import java.util.List;

public class Common {
    public static Comic comicSelected;

    public static Chapter chapterSelected;
    public static List<Comic> comicList = new ArrayList<>();
    public static List<Chapter> chapterList;

    public static int chapterIndex = -1;
    public static String formatString(String name) {
        StringBuilder finalResult = new StringBuilder(name.length() > 15?name.substring(0,15) + "...":name);
        return finalResult.toString();
}
}
