package com.example.mangareader.Interface;

import android.view.View;

public interface IRecyclerItemClickListener {
    void onCLick(View view,final int position);
}
