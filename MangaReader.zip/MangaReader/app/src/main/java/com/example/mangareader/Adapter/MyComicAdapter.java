package com.example.mangareader.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.example.mangareader.ChapterActivity;
import com.example.mangareader.Common.Common;
import com.example.mangareader.Interface.IRecyclerItemClickListener;
import com.example.mangareader.Model.Comic;
import com.example.mangareader.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class MyComicAdapter extends RecyclerView.Adapter<MyComicAdapter.MyViewHolder> {

   static Context context;
   List<Comic> comicList;
   LayoutInflater inflater;

   public MyComicAdapter(Context context,List<Comic> comicList){
       this.context=context;
       this.comicList =comicList;
       inflater = LayoutInflater.from(context);
   }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView = inflater.inflate(R.layout.comic_item,viewGroup,false);
        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.startActivity(new Intent(context, ChapterActivity.class ));
            }
        });
       return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {
        Picasso.get().load(comicList.get(i).Image).into(myViewHolder.comic_image);
       myViewHolder.comic_name.setText(comicList.get(i).Name);
       //Event
      /*myViewHolder.setRecycleritemClickListener(new IRecyclerItemClickListener() {
          @Override
          public void onCLick(View view, int position) {
              Common.comicSelected=comicList.get(position);
              context.startActivity(new Intent(context, ChapterActivity.class ));
          }
      });*/
    }

    @Override
    public int getItemCount() {
        return comicList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView comic_name;
        ImageView comic_image;
        IRecyclerItemClickListener recyclerItemClickListener;

        public void setRecycleritemClickListener(IRecyclerItemClickListener recycleritemClickListener){

        this.recyclerItemClickListener = recyclerItemClickListener;

        }

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            comic_image = itemView.findViewById(R.id.image_comic);
            comic_name =itemView.findViewById(R.id.comic_name);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
//                recyclerItemClickListener.onCLick(view,getAdapterPosition());
                Intent i = new Intent(context, ChapterActivity.class );
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
        }
    }
}
