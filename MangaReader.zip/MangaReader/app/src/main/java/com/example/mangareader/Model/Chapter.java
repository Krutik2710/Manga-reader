package com.example.mangareader.Model;

import java.util.List;

public class Chapter {
    public String Name;
    public List<String> Links;
    public Chapter(){}
}
