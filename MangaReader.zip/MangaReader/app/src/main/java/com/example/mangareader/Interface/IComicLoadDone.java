package com.example.mangareader.Interface;

import com.example.mangareader.Model.Comic;
import com.example.mangareader.Model.Comic;

import java.util.List;

public interface IComicLoadDone {
     void onComicLoadListener(List<Comic> comicList);
}
