package com.example.mangareader.Service;

public class PicassoLoadingService  {
}
