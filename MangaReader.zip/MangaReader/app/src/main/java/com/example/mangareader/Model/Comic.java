package com.example.mangareader.Model;

import java.util.List;

public class Comic {
    public String Name;
    public String Image;
    public String Catagory;
    public List<Chapter> Chapters;
}
