package com.example.mangareader;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Login_Page extends AppCompatActivity {

    //DatabaseReference dbReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://comic-reader-75cf9-default-rtdb.firebaseio.com/");

    //LOGIN PAGE
    TextInputEditText username, pass;
    Button loginBtn;
    TextView forgot_pass_txt, signup_txt;
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);

        username = findViewById(R.id.user);
        pass = findViewById(R.id.pass);
        loginBtn = findViewById(R.id.login_btn);
        forgot_pass_txt = findViewById(R.id.forgot);
        signup_txt = findViewById(R.id.signup);
        mAuth = FirebaseAuth.getInstance();

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                final String user_txt = username.getText().toString();
                final String pass_txt = pass.getText().toString();

                if( TextUtils.isEmpty(user_txt) || TextUtils.isEmpty(pass_txt))
                {
                    Toast.makeText(Login_Page.this, "Enter your username or password", Toast.LENGTH_LONG).show();
                    return;
                }
                else
                {
                    mAuth.signInWithEmailAndPassword(user_txt, pass_txt)
                            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        // Sign in success, update UI with the signed-in user's information
                                        Toast.makeText(Login_Page.this, "Logged_in", Toast.LENGTH_LONG).show();
                                        startActivity(new Intent(Login_Page.this, MainActivity.class));

                                    } else {
                                        // If sign in fails, display a message to the user.
                                        Toast.makeText(getApplicationContext(), "Authentication failed.",
                                                Toast.LENGTH_SHORT).show();

                                    }
                                }
                            });
                }
            }
        });

        signup_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Login_Page.this, Sign_Up_Page.class));
            }
        });

        forgot_pass_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Login_Page.this, ForgotPassword.class));
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
            currentUser.reload();
        }
    }
}