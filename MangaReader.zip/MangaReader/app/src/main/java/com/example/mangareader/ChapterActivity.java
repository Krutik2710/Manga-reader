package com.example.mangareader;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toolbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mangareader.Adapter.MyChapterAdapter;
import com.example.mangareader.Common.Common;
import com.example.mangareader.Model.Comic;

public class ChapterActivity extends AppCompatActivity {

    RecyclerView recycler_chapter;
    LinearLayoutManager layoutManager;
    TextView txt_chapter_name;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chapter);
        Button btn1;
        btn1 = findViewById(R.id.btn1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Intent i = new Intent(MainActivity.this, hello_activity.class);

                Intent i = new Intent (ChapterActivity.this, p1.class);
                startActivity(i);

            }
        });
        ImageButton back;
        back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Intent i = new Intent(MainActivity.this, hello_activity.class);

                Intent i = new Intent (ChapterActivity.this, MainActivity.class);
                startActivity(i);

            }
        });
        //View
        txt_chapter_name = findViewById(R.id.txt_chapter_name);
        recycler_chapter = findViewById(R.id.recycler_chapter);
        recycler_chapter.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recycler_chapter.setLayoutManager(layoutManager);
        recycler_chapter.addItemDecoration(new DividerItemDecoration(this,layoutManager.getOrientation()));

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("One Piece");


//        set icon
        toolbar.setNavigationIcon(R.drawable.baseline_chevron_left_24);
        toolbar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("ajaykapase","OnClick Called");
                finish();
            }
        });
//                fetchChapter(Common.comicSelected);


    }
    private void fetchChapter(Comic comicSelected)
    {
//        Log.d("ajaykapase",comicSelected.toString());
//        Common.chapterList = comicSelected.Chapters;

//        recycler_chapter.setAdapter(new MyChapterAdapter(this,comicSelected.Chapters));
//        txt_chapter_name.setText(new StringBuilder("CHAPTERS(").append(comicSelected.Chapters.size()).append(")"));
    }
}